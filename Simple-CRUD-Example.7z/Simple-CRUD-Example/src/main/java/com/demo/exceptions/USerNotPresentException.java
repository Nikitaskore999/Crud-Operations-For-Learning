package com.demo.exceptions;

public class USerNotPresentException extends RuntimeException{

	String message;
	
	USerNotPresentException(){
		
	}
	
	public USerNotPresentException(String message) {
	    super(message);
	    this.message=message;
	}
	
	

}
