package com.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.User;
import com.demo.exceptions.USerNotPresentException;
import com.demo.repository.USerRepository;

@Service
public class UserService {
	
	@Autowired
	USerRepository userRepo;
	
	
	public User saveUser(User user) {
		System.out.println("============Save User=================");
		User saveUser=userRepo.save(user);
		return saveUser;
		
	}

	public List<User> getAllUsers() {
		System.out.println("===========All Users From DB===============");
		List<User> allUsers=userRepo.findAll();
		return allUsers;
		
	}
	
	public User findByUserName(String name) {
		System.out.println("========Find User By Name============");
		User user=userRepo.findByName(name);
		if(user.getName().equals(name)) {
			return user;
			
		}
		else {
			throw new USerNotPresentException("User is not presernt");
		}
	}

	public User updateUserInDb(User user,int id) {
		System.out.println("===========Update user========");
		User exist_user=userRepo.findById(user.getId()).get();
		exist_user.setCompany(user.getCompany());
		exist_user.setCity(user.getCity());
		User saveUserData=userRepo.save(exist_user);
		return saveUserData;

	}

	public User findByUserid(int id) {
		
		User findById=userRepo.findById(id).get();
		return findById;
	}
}
